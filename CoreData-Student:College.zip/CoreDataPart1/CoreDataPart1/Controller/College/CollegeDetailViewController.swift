//
//  CollegeDetailViewController.swift
//  CoreDataPart1
//
//  Created by Yogesh Patel on 08/04/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class CollegeDetailViewController: UITableViewController {

    @IBOutlet var lblCollegename: UILabel!
    @IBOutlet var lblCollegeAddress: UILabel!
    @IBOutlet var lblCollegeCity: UILabel!
    @IBOutlet var lblCollegeUniversity: UILabel!
    var collegeDetail: College?
    var indexRow = Int()
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        lblCollegename.text =  collegeDetail?.name
        lblCollegeCity.text = collegeDetail?.city ?? ""
        lblCollegeUniversity.text = collegeDetail?.university ?? ""
        lblCollegeAddress.text = collegeDetail?.address ?? ""
    }

    @IBAction func btnEditClick(_ sender: UIBarButtonItem) {
        let formVC = self.storyboard?.instantiateViewController(withIdentifier: "CollegeFormViewController") as! CollegeFormViewController
        formVC.isUpdate = true
        formVC.collegeDetails = collegeDetail
        formVC.indexRow = indexRow
        self.navigationController?.pushViewController(formVC, animated: false)
    }
}

//
//  CollegeListViewCell.swift
//  CoreDataPart1
//
//  Created by Yogesh Patel on 07/04/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class CollegeListViewCell: UITableViewCell {

    @IBOutlet var lblCollegeName: UILabel!
    @IBOutlet var lblCollegeCity: UILabel!
   @IBOutlet var lblCollegeUniversity: UILabel!
    
    var college: College?{
        didSet{
            lblCollegeName.text =  "Name : \(college?.name ?? "")"
            lblCollegeCity.text = "City: \(college?.city ?? "")"
            lblCollegeUniversity.text = "University: \(college?.university ?? "")"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

}
